import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

import 'player_chord_sheet.dart';
import 'studio_native_pages.dart';

final Uri cifrasHome = Uri.https('www.cifras.com.br', '/');

bool isChordSourceUri(Uri uri) =>
    uri.scheme == 'https' &&
    uri.userInfo.isEmpty &&
    uri.port == 443 &&
    const {'www.cifras.com.br', 'cifras.com.br'}.contains(uri.host);

bool isChordPageUri(Uri uri) =>
    isChordSourceUri(uri) &&
    uri.pathSegments.length >= 3 &&
    uri.pathSegments.first == 'cifra';

/// Opens the site's own visible results page with its search field populated.
Uri chordSearchUri(String query) {
  final value = query.trim();
  if (value.isEmpty || value.length > 240) {
    throw const FormatException(
      'Escreva uma música ou artista (até 240 caracteres).',
    );
  }
  return Uri.https('www.cifras.com.br', '/busca', {'q': value});
}

Uri? chordNavigationUri(String value) {
  final uri = Uri.tryParse(value);
  if (uri == null) return null;
  if (isChordSourceUri(uri)) return uri;
  if (uri.scheme != 'https' || uri.userInfo.isNotEmpty || uri.port != 443) {
    return null;
  }
  return null;
}

class ImportedChord {
  const ImportedChord({
    required this.title,
    required this.url,
    required this.text,
  });
  final String title, text;
  final Uri url;

  factory ImportedChord.decode(Object raw, {required Uri expectedUrl}) {
    dynamic value = raw;
    for (var i = 0; i < 2 && value is String; i++) {
      if (value.length > 100000) {
        throw const FormatException('Página demasiado grande.');
      }
      value = jsonDecode(value);
    }
    if (value is! Map ||
        value['text'] is! String ||
        value['url'] is! String ||
        value['title'] is! String) {
      throw const FormatException(
        'Não foi possível ler uma cifra nesta página.',
      );
    }
    if (value['error'] != null) {
      throw const FormatException(
        'Abra a página de uma música com a cifra visível. Não é possível importar pesquisa, bloqueios ou conteúdo protegido.',
      );
    }
    final uri = Uri.tryParse(value['url']);
    if (uri == null || !isChordPageUri(uri) || uri != expectedUrl) {
      throw const FormatException('A página mudou. Volte a tocar em importar.');
    }
    final text = validatePlayerChordText(value['text']);
    final chordRows = text
        .split('\n')
        .where(
          (line) => RegExp(
            r'(^|\s)[A-G](?:#|b)?(?:m|maj|sus|dim|add)?\d*(?:/[A-G][#b]?)?(?=\s|$)',
          ).hasMatch(line),
        );
    if (chordRows.isEmpty) {
      throw const FormatException(
        'Não foram encontrados acordes nesta página.',
      );
    }
    final title = (value['title'] as String).trim();
    if (title.length > 240) {
      throw const FormatException('Título da página demasiado longo.');
    }
    return ImportedChord(
      title: title.isEmpty ? 'Cifra importada' : title,
      url: uri,
      text: text,
    );
  }
}

/// Read-only DOM extraction of the visible chord page, before user approval.
/// Does not fetch hidden APIs, alter the site, bypass challenges or execute HTML.
const chordExtractionScript = r'''(() => {
  const result = {title: (document.querySelector('h1')?.innerText || document.title || '').trim().slice(0, 240),
    url: location.href, text: '', error: null};
  const visible = el => {
    for (let node = el; node && node.nodeType === 1; node = node.parentElement) {
      const css = getComputedStyle(node);
      if (node.hidden || node.getAttribute('aria-hidden') === 'true' || css.display === 'none' || css.visibility === 'hidden') return false;
    }
    return el.getClientRects().length > 0;
  };
  const candidates = [...document.querySelectorAll('pre, .cifra_cnt, .cifra-content, #cifra')]
    .filter(visible).map(el => el.innerText || '').filter(text => text.trim().length > 0);
  const score = text => text.split('\n').filter(line => /(^|\s)[A-G](?:#|b)?(?:m|maj|sus|dim|add)?\d*(?:\/[A-G][#b]?)?(?=\s|$)/.test(line)).length;
  candidates.sort((a, b) => score(b) - score(a));
  const chosen = candidates[0] || '';
  if (!chosen || score(chosen) === 0) result.error = 'no-visible-chord';
  else if (chosen.length > 10000) result.error = 'too-long';
  else result.text = chosen;
  return JSON.stringify(result);
})()''';

const chordSearchResultsScrollScript = r'''(() => {
  if (location.pathname !== '/busca' && location.pathname !== '/') return false;
  window.scrollBy({top: window.innerHeight, left: 0, behavior: 'instant'});
  return true;
})()''';

class ChordSearchResult {
  const ChordSearchResult({required this.title, required this.url});
  final String title;
  final Uri url;
}

/// Reads only the song links rendered in the site's public search page.
const chordResultsScript =
    r'''(() => JSON.stringify([...document.querySelectorAll('a[href]')]
  .filter(a => a.getClientRects().length && a.href && new URL(a.href).pathname.startsWith('/cifra/'))
  .map(a => ({title: (a.innerText || a.getAttribute('title') || '').trim().replace(/\s+/g, ' ').slice(0, 180), url: a.href}))
  .filter(item => item.title).slice(0, 60)))()''';

List<ChordSearchResult> decodeChordSearchResults(Object raw) {
  dynamic value = raw;
  for (var i = 0; i < 2 && value is String; i++) {
    if (value.length > 100000) return const [];
    value = jsonDecode(value);
  }
  if (value is! List) return const [];
  final seen = <Uri>{};
  return value
      .whereType<Map>()
      .map((entry) {
        final title = entry['title'];
        final url = entry['url'];
        final uri = url is String ? Uri.tryParse(url) : null;
        if (title is! String ||
            uri == null ||
            !isChordPageUri(uri) ||
            !seen.add(uri)) {
          return null;
        }
        return ChordSearchResult(title: title.trim(), url: uri);
      })
      .whereType<ChordSearchResult>()
      .toList(growable: false);
}

abstract class ChordBrowserSession extends ChangeNotifier {
  Uri? get currentUri;
  int get progress;
  String? get error;
  bool get canGoBack;
  Future<void> open(Uri uri);
  Future<void> goBack();
  Future<void> reload();
  Future<ImportedChord> extract();
  Future<List<ChordSearchResult>> searchResults() async => const [];
  Widget buildView();
}

class WebViewChordBrowser extends ChordBrowserSession {
  WebViewChordBrowser()
    : controller = WebViewController(
        onPermissionRequest: (request) => request.deny(),
      );
  final WebViewController controller;
  Uri? _uri;
  int _progress = 0, _revision = 0;
  bool _disposed = false, _back = false;
  String? _error;
  Future<void>? _setup;
  @override
  Uri? get currentUri => _uri;
  @override
  int get progress => _progress;
  @override
  bool get canGoBack => _back;
  @override
  String? get error => _error;
  void _notify() {
    if (!_disposed) notifyListeners();
  }

  Future<void> _configure() async {
    await controller.setJavaScriptMode(JavaScriptMode.unrestricted);
    await controller.setBackgroundColor(studioBg);
    if (controller.platform is AndroidWebViewController) {
      await AndroidWebViewController.enableDebugging(kDebugMode);
      await (controller.platform as AndroidWebViewController)
          .setMediaPlaybackRequiresUserGesture(true);
    }
    await controller.setNavigationDelegate(
      NavigationDelegate(
        onNavigationRequest: (request) {
          if (!request.isMainFrame) return NavigationDecision.navigate;
          final target = chordNavigationUri(request.url);
          if (target == null) {
            _error = 'Só é possível abrir páginas do Cifras.com.br.';
            _notify();
            return NavigationDecision.prevent;
          }
          if (target.toString() != request.url) {
            unawaited(open(target));
            return NavigationDecision.prevent;
          }
          return NavigationDecision.navigate;
        },
        onPageStarted: (url) {
          _revision++;
          _uri = Uri.tryParse(url);
          _progress = 0;
          _error = null;
          _notify();
        },
        onUrlChange: (change) {
          final uri = Uri.tryParse(change.url ?? '');
          if (uri != _uri) {
            _revision++;
            _uri = uri;
            _notify();
          }
        },
        onProgress: (value) {
          _progress = value;
          _notify();
        },
        onPageFinished: (_) async {
          final revision = _revision;
          try {
            final back = await controller.canGoBack();
            if (_disposed || revision != _revision) return;
            _back = back;
            _progress = 100;
            _notify();
            if (_uri?.path == '/busca' || _uri?.path == '/') {
              unawaited(_scrollSearchResults(revision));
            }
          } on Object {
            // Closing the browser may destroy its platform view mid-callback.
            if (!_disposed && revision == _revision) {
              _progress = 100;
              _notify();
            }
          }
        },
        onWebResourceError: (failure) {
          if (failure.isForMainFrame != true) return;
          _error =
              'Não foi possível abrir o Cifras.com.br. Verifique a ligação.';
          _progress = 100;
          _notify();
        },
      ),
    );
  }

  Future<void> _scrollSearchResults(int revision) async {
    await Future<void>.delayed(const Duration(milliseconds: 450));
    if (_disposed ||
        revision != _revision ||
        (_uri?.path != '/busca' && _uri?.path != '/')) {
      return;
    }
    try {
      await controller.runJavaScript(chordSearchResultsScrollScript);
    } on Object {
      // The site can navigate again while this page finishes rendering.
    }
  }

  @override
  Future<void> open(Uri uri) async {
    final target = chordNavigationUri(uri.toString());
    if (target == null) {
      throw const FormatException('Endereço de cifra não suportado.');
    }
    await (_setup ??= _configure());
    if (!_disposed) await controller.loadRequest(target);
  }

  @override
  Future<void> goBack() => controller.goBack();
  @override
  Future<void> reload() => controller.reload();
  @override
  Future<ImportedChord> extract() async {
    final revision = _revision;
    final current = Uri.tryParse(await controller.currentUrl() ?? '');
    if (current == null || !isChordPageUri(current) || _disposed) {
      throw const FormatException('Escolha primeiro uma página de cifra.');
    }
    final result = await controller
        .runJavaScriptReturningResult(chordExtractionScript)
        .timeout(const Duration(seconds: 8));
    final after = Uri.tryParse(await controller.currentUrl() ?? '');
    if (_disposed || revision != _revision || current != after) {
      throw const FormatException(
        'A página mudou durante a importação. Tente novamente.',
      );
    }
    return ImportedChord.decode(result, expectedUrl: current);
  }

  @override
  Future<List<ChordSearchResult>> searchResults() async {
    if (_disposed || _uri?.path != '/busca') return const [];
    final result = await controller.runJavaScriptReturningResult(
      chordResultsScript,
    );
    return decodeChordSearchResults(result);
  }

  @override
  Widget buildView() => WebViewWidget(controller: controller);
  @override
  void dispose() {
    _disposed = true;
    _revision++;
    super.dispose();
  }
}

/// Native Transpono search/results UI; the site page is kept in a tiny,
/// non-interactive WebView solely to read its publicly displayed song links.
class ChordSearchPanel extends StatefulWidget {
  const ChordSearchPanel({
    super.key,
    required this.initialQuery,
    required this.onCancel,
    required this.onSelected,
    this.sessionFactory,
  });

  final String initialQuery;
  final VoidCallback onCancel;
  final Future<void> Function(ImportedChord) onSelected;
  final ChordBrowserSession Function()? sessionFactory;

  @override
  State<ChordSearchPanel> createState() => _ChordSearchPanelState();
}

class _ChordSearchPanelState extends State<ChordSearchPanel> {
  late final ChordBrowserSession _session =
      widget.sessionFactory?.call() ?? WebViewChordBrowser();
  late final Widget _siteView = _session.buildView();
  late final TextEditingController _query = TextEditingController(
    text: widget.initialQuery,
  );
  List<ChordSearchResult> _results = const [];
  String? _error;
  Uri? _lastReadyUri;
  bool _loading = false;
  int _generation = 0;

  @override
  void initState() {
    super.initState();
    _session.addListener(_changed);
    if (_query.text.trim().isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _search());
    }
  }

  @override
  void dispose() {
    _generation++;
    _session.removeListener(_changed);
    _session.dispose();
    _query.dispose();
    super.dispose();
  }

  void _changed() {
    if (!mounted) return;
    final uri = _session.currentUri;
    if (uri != null && _session.progress >= 100 && uri != _lastReadyUri) {
      _lastReadyUri = uri;
      final generation = _generation;
      if (uri.path == '/busca') {
        unawaited(_readResults(generation));
      } else if (isChordPageUri(uri)) {
        unawaited(_readChord(generation, uri));
      }
    }
    setState(() {});
  }

  Future<void> _search() async {
    final query = _query.text.trim();
    Uri uri;
    try {
      uri = chordSearchUri(query);
    } on FormatException catch (error) {
      setState(() => _error = error.message);
      return;
    }
    final generation = ++_generation;
    setState(() {
      _loading = true;
      _error = null;
      _results = const [];
      _lastReadyUri = null;
    });
    try {
      await _session.open(uri);
    } on Object {
      if (mounted && generation == _generation) {
        setState(() {
          _loading = false;
          _error = 'Não foi possível pesquisar no Cifras.com.br.';
        });
      }
    }
  }

  Future<void> _readResults(int generation) async {
    for (var attempt = 0; attempt < 8; attempt++) {
      if (!mounted || generation != _generation) return;
      if (attempt > 0) {
        await Future<void>.delayed(const Duration(milliseconds: 450));
      }
      if (!mounted ||
          generation != _generation ||
          _session.currentUri?.path != '/busca') {
        return;
      }
      try {
        final results = await _session.searchResults();
        if (!mounted || generation != _generation) return;
        if (results.isNotEmpty) {
          setState(() {
            _results = results;
            _loading = false;
            _error = null;
          });
          return;
        }
      } on Object {
        // The dynamic results may not have finished rendering yet.
      }
    }
    if (mounted && generation == _generation) {
      setState(() {
        _loading = false;
        _error = _session.error ?? 'Nenhuma cifra encontrada. Experimente pesquisar por música e artista.';
      });
    }
  }

  Future<void> _choose(ChordSearchResult result) async {
    final generation = ++_generation;
    setState(() {
      _loading = true;
      _error = null;
      _lastReadyUri = null;
    });
    try {
      await _session.open(result.url);
    } on Object {
      if (mounted && generation == _generation) {
        setState(() {
          _loading = false;
          _error = 'Não foi possível abrir esta cifra. Tente outra.';
        });
      }
    }
  }

  Future<void> _readChord(int generation, Uri uri) async {
    for (var attempt = 0; attempt < 5; attempt++) {
      if (attempt > 0) {
        await Future<void>.delayed(const Duration(milliseconds: 450));
      }
      if (!mounted || generation != _generation || _session.currentUri != uri) {
        return;
      }
      try {
        final chord = await _session.extract();
        if (!mounted || generation != _generation) return;
        await widget.onSelected(chord);
        return;
      } on Object {
        // A visible chord can be inserted shortly after page load.
      }
    }
    if (mounted && generation == _generation) {
      setState(() {
        _loading = false;
        _error = 'Não foi possível ler esta cifra. Escolha outro resultado.';
      });
    }
  }

  @override
  Widget build(BuildContext context) => Stack(
    children: [
      Positioned(
        left: 0,
        right: 0,
        top: 0,
        height: 320,
        child: IgnorePointer(
          child: ExcludeSemantics(child: Opacity(opacity: 0, child: _siteView)),
        ),
      ),
      SingleChildScrollView(
        key: const Key('chordNativeResults'),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      key: const Key('chordNativeQuery'),
                      controller: _query,
                      textInputAction: TextInputAction.search,
                      onSubmitted: (_) => _search(),
                      decoration: const InputDecoration(
                        labelText: 'Música ou artista',
                        isDense: true,
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  IconButton(
                    key: const Key('chordNativeSearch'),
                    tooltip: 'Pesquisar cifras',
                    onPressed: _search,
                    icon: const Icon(Icons.search),
                  ),
                  IconButton(
                    key: const Key('chordNativeClose'),
                    tooltip: 'Fechar pesquisa',
                    onPressed: widget.onCancel,
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
            ),
            if (_loading || _session.progress < 100)
              const LinearProgressIndicator(),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.all(12),
                child: Text(_error!, key: const Key('chordNativeError')),
              ),
            for (var index = 0; index < _results.length; index++)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                child: Material(
                  color: const Color(0xFF102338),
                  borderRadius: BorderRadius.circular(12),
                  child: InkWell(
                    key: Key('chordNativeResult$index'),
                    borderRadius: BorderRadius.circular(12),
                    onTap: _loading ? null : () => _choose(_results[index]),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 9,
                      ),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.library_music_outlined,
                            size: 18,
                            color: studioCyan,
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              _results[index].title,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 14,
                                height: 1.15,
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          const Icon(Icons.chevron_right, size: 18),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    ],
  );
}

class ChordBrowserPage extends StatefulWidget {
  const ChordBrowserPage({
    super.key,
    this.initialQuery = '',
    this.sessionFactory,
  });
  final String initialQuery;
  final ChordBrowserSession Function()? sessionFactory;
  @override
  State<ChordBrowserPage> createState() => _ChordBrowserPageState();
}

class _ChordBrowserPageState extends State<ChordBrowserPage> {
  late final ChordBrowserSession _session =
      widget.sessionFactory?.call() ?? WebViewChordBrowser();
  late final Widget _view = _session.buildView();
  bool _preparing = false;
  ImportedChord? _prepared;
  Uri? _observedUri, _requestedUri;
  int _generation = 0, _lastProgress = 0;
  String? _error;

  @override
  void initState() {
    super.initState();
    _session.addListener(_sessionChanged);
    final query = widget.initialQuery.trim();
    unawaited(
      _run(
        () => _session.open(query.isEmpty ? cifrasHome : chordSearchUri(query)),
      ),
    );
  }

  @override
  void dispose() {
    _session.removeListener(_sessionChanged);
    _session.dispose();
    super.dispose();
  }

  Future<void> _run(Future<void> Function() action) async {
    if (mounted) setState(() => _error = null);
    try {
      await action();
    } on FormatException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } on Object {
      if (mounted) {
        setState(() => _error = 'Não foi possível carregar. Tente novamente.');
      }
    }
  }

  void _sessionChanged() {
    if (!mounted) return;
    final uri = _session.currentUri;
    final progress = _session.progress;
    if (uri != _observedUri || (progress < 100 && _lastProgress == 100)) {
      _generation++;
      _observedUri = uri;
      _requestedUri = null;
      _prepared = null;
      _preparing = false;
      _error = null;
    }
    _lastProgress = progress;
    if (uri != null &&
        isChordPageUri(uri) &&
        progress >= 100 &&
        _requestedUri != uri) {
      _requestedUri = uri;
      unawaited(_prepare(uri, _generation));
    }
    setState(() {});
  }

  Future<void> _prepare(Uri uri, int generation) async {
    if (!mounted || generation != _generation) return;
    setState(() {
      _preparing = true;
      _error = null;
    });
    for (var attempt = 0; attempt < 3; attempt++) {
      if (attempt > 0) {
        await Future<void>.delayed(const Duration(milliseconds: 450));
      }
      if (!mounted || generation != _generation || _session.currentUri != uri) {
        return;
      }
      try {
        final chord = await _session.extract();
        if (!mounted ||
            generation != _generation ||
            _session.currentUri != uri) {
          return;
        }
        setState(() {
          _prepared = chord;
          _preparing = false;
          _error = null;
        });
        return;
      } on Object {
        // The visible chord block may appear shortly after page load.
      }
    }
    if (mounted && generation == _generation && _session.currentUri == uri) {
      setState(() {
        _preparing = false;
        _error = 'Não foi possível ler esta cifra. Abra uma página de música com os acordes visíveis ou tente novamente.';
      });
    }
  }

  void _retryPreparation() {
    final uri = _session.currentUri;
    if (uri == null || !isChordPageUri(uri) || _preparing) return;
    _requestedUri = uri;
    unawaited(_prepare(uri, _generation));
  }

  void _usePrepared() {
    final chord = _prepared;
    if (chord == null || chord.url != _session.currentUri) return;
    Navigator.pop(context, chord);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    key: const Key('chordBrowserPage'),
    body: SafeArea(
      child: ListenableBuilder(
        listenable: _session,
        builder: (context, _) => Column(
          children: [
            Row(
              children: [
                IconButton(
                  key: const Key('chordBrowserClose'),
                  tooltip: 'Voltar ao player',
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close),
                ),
                const Expanded(
                  child: Text(
                    'Cifras.com.br',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                  ),
                ),
                IconButton(
                  key: const Key('chordBrowserBack'),
                  tooltip: 'Página anterior',
                  onPressed: _session.canGoBack
                      ? () => _run(_session.goBack)
                      : null,
                  icon: const Icon(Icons.arrow_back),
                ),
                IconButton(
                  key: const Key('chordBrowserReload'),
                  tooltip: 'Atualizar',
                  onPressed: () => _run(_session.reload),
                  icon: const Icon(Icons.refresh),
                ),
              ],
            ),
            if (_session.progress < 100)
              LinearProgressIndicator(value: _session.progress / 100),
            if (_error != null || _session.error != null)
              Padding(
                padding: const EdgeInsets.all(8),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        _error ?? _session.error!,
                        key: const Key('chordBrowserError'),
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (_error != null &&
                        _session.currentUri != null &&
                        isChordPageUri(_session.currentUri!))
                      TextButton(
                        key: const Key('chordBrowserRetry'),
                        onPressed: _retryPreparation,
                        child: const Text('Tentar ler'),
                      ),
                  ],
                ),
              ),
            Expanded(child: _view),
            if (MediaQuery.viewInsetsOf(context).bottom == 0)
              Padding(
                padding: const EdgeInsets.all(10),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    key: const Key('chordBrowserImport'),
                    onPressed:
                        _prepared != null &&
                            _prepared!.url == _session.currentUri
                        ? _usePrepared
                        : null,
                    icon: const Icon(Icons.check),
                    label: Text(
                      _preparing ? 'A preparar cifra…' : 'Usar esta cifra',
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    ),
  );
}
